const DEFAULT_SPEED = 500;

const SubmitFormText = {
  IDLE: 'Отправить',
  SENDING: 'Отправляю...',
};

export { DEFAULT_SPEED, SubmitFormText };
