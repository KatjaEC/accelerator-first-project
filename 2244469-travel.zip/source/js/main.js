import './hero-slider';
import './header-menu';
import './tours-slider';
import './instructors-slider';
import './advantages-slider';
import './reviews-slider';
import './gallery-slider';
import './form';
